---
name: id4ai-add-mcp
description: "Add an MCP server behind PingGateway. Use when asked to onboard, add, protect, proxy, or publish an MCP server route: discover the MCP server with initialize plus tools/list, derive deterministic scopes in the form mcp:server:tool, generate and validate a PingGateway JSON route from the bundled template, then publish it to GitHub with the gh CLI using a branch and pull request. This is the id4ai add_mcp workflow."
---

# ID4AI Add MCP

Create a PingGateway route for an MCP server and publish it through GitHub.

## Required inputs

Collect or derive:

- `mcp_server_name`: short stable identifier, for example `crm`.
- `mcp_url`: complete MCP endpoint URL, including its MCP path.
- `public_path`: PingGateway path exposed to clients.
- `github_repo`: GitHub repository as `owner/repo`.
- `github_target_dir`: repository directory for PingGateway routes.

Optional:

- Base branch. Default to the repository default branch.
- Branch name. Default to `id4ai/add-mcp-<mcp_server_name>`.

## Workflow

Execute these steps in order.

### 1. Discover MCP tools

Run:

```bash
python scripts/discover_mcp.py \
  --server-name <mcp_server_name> \
  --url <mcp_url> \
  --output <manifest.json>
```

The script must:

1. Send MCP `initialize`.
2. Send the `notifications/initialized` notification.
3. Verify the server advertises the `tools` capability.
4. Call `tools/list`.
5. Follow `nextCursor` until all tools are collected.
6. Generate one scope per tool using `mcp:<server>:<tool>`.
7. Write the normalized discovery manifest.

Treat `tools/list` as authoritative. Never invent, merge, rename semantically, or omit tools.

### 2. Scope convention

Normalize server and tool identifiers deterministically:

- lowercase
- replace runs of unsupported characters with `_`
- collapse duplicate `_`
- trim leading and trailing `_`

Construct every scope as:

```text
mcp:<normalized_mcp_server_name>:<normalized_tool_name>
```

Example:

```text
mcp_server_name = crm
get_customer     -> mcp:crm:get_customer
update_customer  -> mcp:crm:update_customer
```

Do not infer broader `read`, `write`, or `admin` scopes in this iteration.

### 3. Generate the PingGateway route

Run:

```bash
python scripts/generate_route.py \
  --manifest <manifest.json> \
  --public-path <public_path> \
  --output <mcp_server_name>.json
```

Use `assets/mcp-route-template.json` as the route structure.

Keep these filters in this exact order unless the user explicitly requests a different route architecture:

1. `McpAuditFilter`
2. `McpValidationFilter`
3. `MCPPingAuthorizeFilter`
4. `UriPathRewriteFilter`
5. `HeaderFilter`

Use `ReverseProxyHandler` as the terminal handler.

The route name must be `mcp_server_name` after deterministic normalization. Use the MCP URL origin as `mcpServerUrl`; rewrite `public_path` to the path from the MCP URL. Derive the Host header from the MCP URL authority.

### 4. Validate

Run:

```bash
python scripts/validate_route.py <route.json> --manifest <manifest.json>
```

Do not publish if validation fails.

### 5. Publish with GitHub CLI

First verify `gh auth status` succeeds.

Then run:

```bash
bash scripts/publish_github.sh \
  --repo <owner/repo> \
  --route <route.json> \
  --target-dir <github_target_dir> \
  --server-name <mcp_server_name>
```

The script clones the repository into a temporary directory, creates an `id4ai/add-mcp-*` branch, copies the route, commits, pushes, and opens a pull request.

Never put a GitHub PAT, MCP bearer token, client secret, or other credential in the skill, manifest, route, commit, or PR body.

## Output

Return:

- discovered MCP tool names
- generated scopes
- generated route path
- validation result
- branch name
- pull request URL

Keep the discovery manifest available because the next `id4ai` iteration will use it to generate authorization policies from the tool-to-scope mapping.

## Bundled resources

- `scripts/discover_mcp.py`: MCP initialize and paginated tool discovery.
- `scripts/generate_route.py`: render the PingGateway route.
- `scripts/validate_route.py`: deterministic validation.
- `scripts/publish_github.sh`: branch, commit, push, and PR with `gh`.
- `assets/mcp-route-template.json`: PingGateway route template.
- `references/manifest-schema.md`: discovery manifest contract for future authorization-policy generation.
- `README.md`: setup and usage for humans.
