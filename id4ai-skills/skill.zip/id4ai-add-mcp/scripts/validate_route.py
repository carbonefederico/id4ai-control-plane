#!/usr/bin/env python3
import argparse
import json
import sys
from pathlib import Path
from urllib.parse import urlparse

REQUIRED_FILTERS = ["McpAuditFilter", "McpValidationFilter", "MCPPingAuthorizeFilter"]


def fail(msg):
    raise ValueError(msg)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("route")
    parser.add_argument("--manifest")
    args = parser.parse_args()
    try:
        route = json.loads(Path(args.route).read_text(encoding="utf-8"))
        if not isinstance(route.get("name"), str) or not route["name"]:
            fail("route name is missing")
        if not str(route.get("condition", "")).startswith("${find(request.uri.path"):
            fail("unexpected route condition")
        props = route.get("properties") or {}
        origin = props.get("mcpServerUrl")
        parsed = urlparse(origin or "")
        if parsed.scheme not in ("http", "https") or not parsed.netloc:
            fail("properties.mcpServerUrl is not a valid HTTP(S) origin")
        if parsed.path not in ("", "/"):
            fail("properties.mcpServerUrl must be an origin without an MCP path")
        if route.get("baseURI") != "&{mcpServerUrl}":
            fail("baseURI must reference mcpServerUrl")
        handler = route.get("handler") or {}
        if handler.get("type") != "Chain":
            fail("handler type must be Chain")
        config = handler.get("config") or {}
        filters = config.get("filters") or []
        if filters[:3] != REQUIRED_FILTERS:
            fail("required MCP filters are missing or out of order")
        if config.get("handler") != "ReverseProxyHandler":
            fail("terminal handler must be ReverseProxyHandler")
        if len(filters) < 5 or not isinstance(filters[3], dict) or filters[3].get("type") != "UriPathRewriteFilter":
            fail("UriPathRewriteFilter must be the fourth filter")
        if not isinstance(filters[4], dict) or filters[4].get("type") != "HeaderFilter":
            fail("HeaderFilter must be the fifth filter")
        mappings = ((filters[3].get("config") or {}).get("mappings") or {})
        if len(mappings) != 1:
            fail("exactly one URI path rewrite mapping is required")
        public_path, upstream_path = next(iter(mappings.items()))
        if not public_path.startswith("/") or not upstream_path.startswith("/"):
            fail("public and upstream paths must start with /")
        host_values = ((((filters[4].get("config") or {}).get("replace") or {}).get("host")) or [])
        if host_values != [parsed.netloc]:
            fail("Host header does not match mcpServerUrl authority")
        serialized = json.dumps(route).lower()
        for secret_word in ("bearer ", "client_secret", "access_token", "github_token", "password"):
            if secret_word in serialized:
                fail(f"possible secret material found: {secret_word.strip()}")
        if args.manifest:
            manifest = json.loads(Path(args.manifest).read_text(encoding="utf-8"))
            if route["name"] != manifest.get("mcpServerName"):
                fail("route name does not match manifest mcpServerName")
            mcp = urlparse(manifest.get("mcpUrl", ""))
            if f"{mcp.scheme}://{mcp.netloc}" != origin:
                fail("route origin does not match manifest MCP URL")
            if upstream_path != (mcp.path or "/"):
                fail("route upstream path does not match manifest MCP URL")
            expected_prefix = f"mcp:{manifest['mcpServerName']}:"
            for tool in manifest.get("tools", []):
                if tool.get("scope") != expected_prefix + tool.get("normalizedName", ""):
                    fail(f"invalid scope mapping for tool {tool.get('name')}")
        print("VALID")
    except Exception as exc:
        print(f"INVALID: {exc}", file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    main()
