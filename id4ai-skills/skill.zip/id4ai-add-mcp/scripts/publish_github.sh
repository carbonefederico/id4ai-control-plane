#!/usr/bin/env bash
set -euo pipefail

usage() {
  echo "Usage: $0 --repo owner/repo --route route.json --target-dir path --server-name name [--branch branch]" >&2
  exit 2
}

REPO=""
ROUTE=""
TARGET_DIR=""
SERVER_NAME=""
BRANCH=""
while [[ $# -gt 0 ]]; do
  case "$1" in
    --repo) REPO="$2"; shift 2 ;;
    --route) ROUTE="$2"; shift 2 ;;
    --target-dir) TARGET_DIR="$2"; shift 2 ;;
    --server-name) SERVER_NAME="$2"; shift 2 ;;
    --branch) BRANCH="$2"; shift 2 ;;
    *) usage ;;
  esac
done
[[ -n "$REPO" && -n "$ROUTE" && -n "$TARGET_DIR" && -n "$SERVER_NAME" ]] || usage
[[ -f "$ROUTE" ]] || { echo "Route not found: $ROUTE" >&2; exit 1; }
command -v gh >/dev/null || { echo "gh CLI is required" >&2; exit 1; }
command -v git >/dev/null || { echo "git is required" >&2; exit 1; }
gh auth status >/dev/null

SAFE_NAME=$(printf '%s' "$SERVER_NAME" | tr '[:upper:]' '[:lower:]' | sed -E 's/[^a-z0-9_]+/_/g; s/^_+|_+$//g')
[[ -n "$BRANCH" ]] || BRANCH="id4ai/add-mcp-${SAFE_NAME}"
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT

gh repo clone "$REPO" "$TMP/repo" -- --quiet
cd "$TMP/repo"
DEFAULT_BRANCH=$(gh repo view "$REPO" --json defaultBranchRef --jq '.defaultBranchRef.name')
git checkout "$DEFAULT_BRANCH" >/dev/null 2>&1
git pull --ff-only >/dev/null 2>&1
git checkout -b "$BRANCH"
mkdir -p "$TARGET_DIR"
cp "$ROUTE" "$TARGET_DIR/${SAFE_NAME}.json"
git add "$TARGET_DIR/${SAFE_NAME}.json"
if git diff --cached --quiet; then
  echo "No route change to publish" >&2
  exit 1
fi
git commit -m "feat(pinggateway): add MCP route ${SAFE_NAME}"
git push -u origin "$BRANCH"
PR_URL=$(gh pr create --repo "$REPO" --base "$DEFAULT_BRANCH" --head "$BRANCH" \
  --title "Add MCP protection for ${SAFE_NAME}" \
  --body "Adds the PingGateway route for the ${SAFE_NAME} MCP server via the id4ai add_mcp workflow.")
printf '%s\n' "$PR_URL"
