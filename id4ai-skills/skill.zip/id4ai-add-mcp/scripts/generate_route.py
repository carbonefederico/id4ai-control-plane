#!/usr/bin/env python3
import argparse
import json
import re
import sys
from pathlib import Path
from urllib.parse import urlparse


def require_public_path(path: str) -> str:
    if not path.startswith("/"):
        raise ValueError("public path must start with /")
    if path != "/":
        path = path.rstrip("/")
    return path


def replace_template(obj, values):
    if isinstance(obj, dict):
        return {replace_template(k, values): replace_template(v, values) for k, v in obj.items()}
    if isinstance(obj, list):
        return [replace_template(v, values) for v in obj]
    if isinstance(obj, str):
        for key, value in values.items():
            obj = obj.replace("{{" + key + "}}", value)
        return obj
    return obj


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--public-path", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--template", default=str(Path(__file__).resolve().parent.parent / "assets" / "mcp-route-template.json"))
    args = parser.parse_args()
    try:
        manifest = json.loads(Path(args.manifest).read_text(encoding="utf-8"))
        name = manifest["mcpServerName"]
        url = urlparse(manifest["mcpUrl"])
        if url.scheme not in ("http", "https") or not url.netloc:
            raise ValueError("manifest mcpUrl must be an absolute http(s) URL")
        public_path = require_public_path(args.public_path)
        upstream_path = url.path or "/"
        if url.query:
            raise ValueError("MCP URL query strings are not supported in route generation")
        origin = f"{url.scheme}://{url.netloc}"
        values = {
            "mcp_server_name": name,
            "public_path": public_path,
            "mcp_server_origin": origin,
            "upstream_path": upstream_path,
            "backend_host": url.netloc,
        }
        template = json.loads(Path(args.template).read_text(encoding="utf-8"))
        route = replace_template(template, values)
        serialized = json.dumps(route, indent=2) + "\n"
        if re.search(r"\{\{[^}]+\}\}", serialized):
            raise ValueError("unresolved template placeholder")
        out = Path(args.output)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(serialized, encoding="utf-8")
        print(out)
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    main()
